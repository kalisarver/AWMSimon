trialList=data.importConditions(u'Simon_Task_Stimuli.xlsx')
trialList[0]
{u'Stimulus' : u'X', u'Condition': u'Incongruent'}
trialList[1]
{u'Stimulus' : u'X', u'Condition': u'Congruent'}
trialList[2]
{u'Stimulus' : u'O', u'Condition': u'Incongruent'}
trialList[3]
{u'Stimulus' : u'O', u'Condition': u'Congruent'}

