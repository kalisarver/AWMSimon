﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v3.2.4),
    on Wed Dec 11 13:32:18 2019
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '3.2.4'
expName = 'Simon'  # from the Builder filename that created this script
expInfo = {'session': '001', 'participant': '', 'counterbalance': ''}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/Liory/Dropbox/Lectures/IoE/Dissertations/Computerised tsks/PsychoPy/Simon Task/Python coded/Simon_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1440, 900], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Simon_setup"
Simon_setupClock = core.Clock()

# Initialize components for Routine "Simon_trial"
Simon_trialClock = core.Clock()
Fixation = visual.TextStim(win=win, name='Fixation',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
left_stimulus = visual.TextStim(win=win, name='left_stimulus',
    text='default text',
    font='Arial',
    pos=(-0.5, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
Right_stimulus = visual.TextStim(win=win, name='Right_stimulus',
    text='default text',
    font='Arial',
    pos=(0.5, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
ITI = visual.TextStim(win=win, name='ITI',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
Response = keyboard.Keyboard()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=10, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Simon_Task_Stimuli.xlsx'),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial:
        exec('{} = thisTrial[paramName]'.format(paramName))

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Simon_setup"-------
    # update component parameters for each repeat
    if expInfo['counterbalance']=='0':
        bindings = {'X':'m', 'O':'z'}
        if thisTrial['Condition']=='Incongruent':
            if thisTrial['Stimulus']=='X':
                Left_stim_text = thisTrial['Stimulus']
                Right_stim_text = ''
                corrAns = 'm'
            elif thisTrial['Stimulus'] =='O':
                Left_stim_text = ''
                Right_stim_text = thisTrial['Stimulus']
                corrAns = 'z'
        elif thisTrial['Condition']=='Congruent':
            if thisTrial['Stimulus']=='X':
                Left_stim_text = ''
                Right_stim_text = thisTrial['Stimulus']
                corrAns = 'm'
            elif thisTrial['Stimulus'] =='O':
                Left_stim_text = thisTrial['Stimulus']
                Right_stim_text = ''
                corrAns = 'z'
    if expInfo['counterbalance']=='1':
        bindings = {'O':'m', 'X':'z'}
        if thisTrial['Condition']=='Incongruent':
            if thisTrial['Stimulus']=='X':
                Left_stim_text = ''
                Right_stim_text = thisTrial['Stimulus']
                corrAns = 'z'
            elif thisTrial['Stimulus'] =='O':
                Left_stim_text = thisTrial['Stimulus']
                Right_stim_text = ''
                corrAns = 'm'
        elif thisTrial ['Condition']=='Congruent':
            if thisTrial['Stimulus']=='X':
                Left_stim_text = thisTrial['Stimulus']
                Right_stim_text = ''
                corrAns = 'z'
            elif thisTrial['Stimulus'] =='O':
                Left_stim_text = ''
                Right_stim_text = thisTrial['Stimulus']
                corrAns = 'm'
    
    
    
    # keep track of which components have finished
    Simon_setupComponents = []
    for thisComponent in Simon_setupComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Simon_setupClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    continueRoutine = True
    
    # -------Run Routine "Simon_setup"-------
    while continueRoutine:
        # get current time
        t = Simon_setupClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Simon_setupClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Simon_setupComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Simon_setup"-------
    for thisComponent in Simon_setupComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "Simon_setup" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "Simon_trial"-------
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    left_stimulus.setText(Left_stim_text)
    Right_stimulus.setText(Right_stim_text)
    Response.keys = []
    Response.rt = []
    # keep track of which components have finished
    Simon_trialComponents = [Fixation, left_stimulus, Right_stimulus, ITI, Response]
    for thisComponent in Simon_trialComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Simon_trialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    continueRoutine = True
    
    # -------Run Routine "Simon_trial"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = Simon_trialClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Simon_trialClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Fixation* updates
        if Fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Fixation.frameNStart = frameN  # exact frame index
            Fixation.tStart = t  # local t and not account for scr refresh
            Fixation.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Fixation, 'tStartRefresh')  # time at next scr refresh
            Fixation.setAutoDraw(True)
        if Fixation.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Fixation.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                Fixation.tStop = t  # not accounting for scr refresh
                Fixation.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Fixation, 'tStopRefresh')  # time at next scr refresh
                Fixation.setAutoDraw(False)
        
        # *left_stimulus* updates
        if left_stimulus.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            left_stimulus.frameNStart = frameN  # exact frame index
            left_stimulus.tStart = t  # local t and not account for scr refresh
            left_stimulus.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(left_stimulus, 'tStartRefresh')  # time at next scr refresh
            left_stimulus.setAutoDraw(True)
        if left_stimulus.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > left_stimulus.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                left_stimulus.tStop = t  # not accounting for scr refresh
                left_stimulus.frameNStop = frameN  # exact frame index
                win.timeOnFlip(left_stimulus, 'tStopRefresh')  # time at next scr refresh
                left_stimulus.setAutoDraw(False)
        
        # *Right_stimulus* updates
        if Right_stimulus.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Right_stimulus.frameNStart = frameN  # exact frame index
            Right_stimulus.tStart = t  # local t and not account for scr refresh
            Right_stimulus.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Right_stimulus, 'tStartRefresh')  # time at next scr refresh
            Right_stimulus.setAutoDraw(True)
        if Right_stimulus.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Right_stimulus.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                Right_stimulus.tStop = t  # not accounting for scr refresh
                Right_stimulus.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Right_stimulus, 'tStopRefresh')  # time at next scr refresh
                Right_stimulus.setAutoDraw(False)
        
        # *ITI* updates
        if ITI.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
            # keep track of start time/frame for later
            ITI.frameNStart = frameN  # exact frame index
            ITI.tStart = t  # local t and not account for scr refresh
            ITI.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ITI, 'tStartRefresh')  # time at next scr refresh
            ITI.setAutoDraw(True)
        if ITI.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > ITI.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                ITI.tStop = t  # not accounting for scr refresh
                ITI.frameNStop = frameN  # exact frame index
                win.timeOnFlip(ITI, 'tStopRefresh')  # time at next scr refresh
                ITI.setAutoDraw(False)
        
        # *Response* updates
        waitOnFlip = False
        if Response.status == NOT_STARTED and tThisFlip >= 0.2-frameTolerance:
            # keep track of start time/frame for later
            Response.frameNStart = frameN  # exact frame index
            Response.tStart = t  # local t and not account for scr refresh
            Response.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Response, 'tStartRefresh')  # time at next scr refresh
            Response.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(Response.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(Response.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if Response.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Response.tStartRefresh + 1.8-frameTolerance:
                # keep track of stop time/frame for later
                Response.tStop = t  # not accounting for scr refresh
                Response.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Response, 'tStopRefresh')  # time at next scr refresh
                Response.status = FINISHED
        if Response.status == STARTED and not waitOnFlip:
            theseKeys = Response.getKeys(keyList=['z', 'm'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                Response.keys = theseKeys.name  # just the last key pressed
                Response.rt = theseKeys.rt
                # was this 'correct'?
                if (Response.keys == str(corrAns)) or (Response.keys == corrAns):
                    Response.corr = 1
                else:
                    Response.corr = 0
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Simon_trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Simon_trial"-------
    for thisComponent in Simon_trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials.addData('Fixation.started', Fixation.tStartRefresh)
    trials.addData('Fixation.stopped', Fixation.tStopRefresh)
    trials.addData('left_stimulus.started', left_stimulus.tStartRefresh)
    trials.addData('left_stimulus.stopped', left_stimulus.tStopRefresh)
    trials.addData('Right_stimulus.started', Right_stimulus.tStartRefresh)
    trials.addData('Right_stimulus.stopped', Right_stimulus.tStopRefresh)
    trials.addData('ITI.started', ITI.tStartRefresh)
    trials.addData('ITI.stopped', ITI.tStopRefresh)
    # check responses
    if Response.keys in ['', [], None]:  # No response was made
        Response.keys = None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           Response.corr = 1;  # correct non-response
        else:
           Response.corr = 0;  # failed to respond (incorrectly)
    # store data for trials (TrialHandler)
    trials.addData('Response.keys',Response.keys)
    trials.addData('Response.corr', Response.corr)
    if Response.keys != None:  # we had a response
        trials.addData('Response.rt', Response.rt)
    trials.addData('Response.started', Response.tStartRefresh)
    trials.addData('Response.stopped', Response.tStopRefresh)
    thisExp.nextEntry()
    
# completed 10 repeats of 'trials'

# get names of stimulus parameters
if trials.trialList in ([], [None], None):
    params = []
else:
    params = trials.trialList[0].keys()
# save data for this loop
trials.saveAsExcel(filename + '.xlsx', sheetName='trials',
    stimOut=params,
    dataOut=['n','all_mean','all_std', 'all_raw'])

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
