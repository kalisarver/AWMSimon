#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v3.2.4),
    on Wed Dec 11 13:49:54 2019
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__)).decode(sys.getfilesystemencoding())
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'SimonTask'  # from the Builder filename that created this script
expInfo = {u'session': u'001', u'participant': u''}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=u'/Users/Liory/Dropbox/Lectures/IoE/Dissertations/Computerised tsks/PsychoPy/Simon Task/SimonTask.psyexp',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=(1440, 900), fullscr=True, screen=0,
    allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Initialize components for Routine "Instuctions"
InstuctionsClock = core.Clock()
Instr = visual.TextStim(win=win, name='Instr',
    text='This is a Simon task.\nOn each trial, you will see either a GREEN shape, or a RED shape.\nWhen you see RED press Z.\nWhen you see GREEN press M.\nTry to repond as quickly and as accurately as possible.\nThe first few trials are practice.\nPress the space bar to begin.',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "ISI"
ISIClock = core.Clock()
blank = visual.TextStim(win=win, name='blank',
    text=None,
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "Practice"
PracticeClock = core.Clock()
Fixation1 = visual.TextStim(win=win, name='Fixation1',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0);
Target = visual.GratingStim(
    win=win, name='Target',
    tex=None, mask=None,
    ori=0, pos=[0,0], size=(6, 6), sf=None, phase=0.0,
    color=1.0, colorSpace='rgb', opacity=1,
    texRes=128, interpolate=True, depth=-2.0)

# Initialize components for Routine "Exp_instr"
Exp_instrClock = core.Clock()
begin = visual.TextStim(win=win, name='begin',
    text='Great! \nPractice over. \nRemember to press Z for RED and M for GREEN\nRespond as quickly and as accurately as possible.\nPress the space bar when you are ready to start the experiment.',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "ISI"
ISIClock = core.Clock()
blank = visual.TextStim(win=win, name='blank',
    text=None,
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "trials"
trialsClock = core.Clock()
Fixation2 = visual.TextStim(win=win, name='Fixation2',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0);
Exp_target = visual.GratingStim(
    win=win, name='Exp_target',
    tex=None, mask=None,
    ori=0, pos=[0,0], size=(6, 6), sf=None, phase=0.0,
    color=1.0, colorSpace='rgb', opacity=1,
    texRes=128, interpolate=True, depth=-1.0)

# Initialize components for Routine "pause"
pauseClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='Take a quick break and hit the space bar when ready to continue',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "ISI"
ISIClock = core.Clock()
blank = visual.TextStim(win=win, name='blank',
    text=None,
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "trials"
trialsClock = core.Clock()
Fixation2 = visual.TextStim(win=win, name='Fixation2',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0);
Exp_target = visual.GratingStim(
    win=win, name='Exp_target',
    tex=None, mask=None,
    ori=0, pos=[0,0], size=(6, 6), sf=None, phase=0.0,
    color=1.0, colorSpace='rgb', opacity=1,
    texRes=128, interpolate=True, depth=-1.0)

# Initialize components for Routine "End"
EndClock = core.Clock()
stop = visual.TextStim(win=win, name='stop',
    text="That's all, thank you!\n",
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Instuctions"-------
t = 0
InstuctionsClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
begin_response = event.BuilderKeyResponse()
# keep track of which components have finished
InstuctionsComponents = [Instr, begin_response]
for thisComponent in InstuctionsComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Instuctions"-------
while continueRoutine:
    # get current time
    t = InstuctionsClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *Instr* updates
    if t >= 0.0 and Instr.status == NOT_STARTED:
        # keep track of start time/frame for later
        Instr.tStart = t
        Instr.frameNStart = frameN  # exact frame index
        Instr.setAutoDraw(True)
    
    # *begin_response* updates
    if t >= 0.0 and begin_response.status == NOT_STARTED:
        # keep track of start time/frame for later
        begin_response.tStart = t
        begin_response.frameNStart = frameN  # exact frame index
        begin_response.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(begin_response.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if begin_response.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            begin_response.keys = theseKeys[-1]  # just the last key pressed
            begin_response.rt = begin_response.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in InstuctionsComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instuctions"-------
for thisComponent in InstuctionsComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if begin_response.keys in ['', [], None]:  # No response was made
    begin_response.keys=None
thisExp.addData('begin_response.keys',begin_response.keys)
if begin_response.keys != None:  # we had a response
    thisExp.addData('begin_response.rt', begin_response.rt)
thisExp.nextEntry()
# the Routine "Instuctions" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
practice_trials = data.TrialHandler(nReps=2, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Simon_practice_file.xlsx'),
    seed=None, name='practice_trials')
thisExp.addLoop(practice_trials)  # add the loop to the experiment
thisPractice_trial = practice_trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisPractice_trial.rgb)
if thisPractice_trial != None:
    for paramName in thisPractice_trial.keys():
        exec(paramName + '= thisPractice_trial.' + paramName)

for thisPractice_trial in practice_trials:
    currentLoop = practice_trials
    # abbreviate parameter names if possible (e.g. rgb = thisPractice_trial.rgb)
    if thisPractice_trial != None:
        for paramName in thisPractice_trial.keys():
            exec(paramName + '= thisPractice_trial.' + paramName)
    
    # ------Prepare to start Routine "ISI"-------
    t = 0
    ISIClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(0.200000)
    # update component parameters for each repeat
    # keep track of which components have finished
    ISIComponents = [blank]
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "ISI"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = ISIClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *blank* updates
        if t >= 0.0 and blank.status == NOT_STARTED:
            # keep track of start time/frame for later
            blank.tStart = t
            blank.frameNStart = frameN  # exact frame index
            blank.setAutoDraw(True)
        frameRemains = 0.0 + 0.2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if blank.status == STARTED and t >= frameRemains:
            blank.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ISIComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ISI"-------
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # ------Prepare to start Routine "Practice"-------
    t = 0
    PracticeClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    Response = event.BuilderKeyResponse()
    Target.setColor(targetcolour, colorSpace='rgb')
    Target.setPos((targetx,targety))
    # keep track of which components have finished
    PracticeComponents = [Fixation1, Response, Target]
    for thisComponent in PracticeComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "Practice"-------
    while continueRoutine:
        # get current time
        t = PracticeClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Fixation1* updates
        if t >= 1 and Fixation1.status == NOT_STARTED:
            # keep track of start time/frame for later
            Fixation1.tStart = t
            Fixation1.frameNStart = frameN  # exact frame index
            Fixation1.setAutoDraw(True)
        
        # *Response* updates
        if t >= 1 and Response.status == NOT_STARTED:
            # keep track of start time/frame for later
            Response.tStart = t
            Response.frameNStart = frameN  # exact frame index
            Response.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(Response.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if Response.status == STARTED:
            theseKeys = event.getKeys(keyList=['m', 'z'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                Response.keys = theseKeys[-1]  # just the last key pressed
                Response.rt = Response.clock.getTime()
                # was this 'correct'?
                if (Response.keys == str(corrAns)) or (Response.keys == corrAns):
                    Response.corr = 1
                else:
                    Response.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *Target* updates
        if t >= 1 and Target.status == NOT_STARTED:
            # keep track of start time/frame for later
            Target.tStart = t
            Target.frameNStart = frameN  # exact frame index
            Target.setAutoDraw(True)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in PracticeComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Practice"-------
    for thisComponent in PracticeComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if Response.keys in ['', [], None]:  # No response was made
        Response.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           Response.corr = 1  # correct non-response
        else:
           Response.corr = 0  # failed to respond (incorrectly)
    # store data for practice_trials (TrialHandler)
    practice_trials.addData('Response.keys',Response.keys)
    practice_trials.addData('Response.corr', Response.corr)
    if Response.keys != None:  # we had a response
        practice_trials.addData('Response.rt', Response.rt)
    # the Routine "Practice" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 2 repeats of 'practice_trials'

# get names of stimulus parameters
if practice_trials.trialList in ([], [None], None):
    params = []
else:
    params = practice_trials.trialList[0].keys()
# save data for this loop
practice_trials.saveAsExcel(filename + '.xlsx', sheetName='practice_trials',
    stimOut=params,
    dataOut=['n','all_mean','all_std', 'all_raw'])

# ------Prepare to start Routine "Exp_instr"-------
t = 0
Exp_instrClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
begin_exp_response = event.BuilderKeyResponse()
# keep track of which components have finished
Exp_instrComponents = [begin, begin_exp_response]
for thisComponent in Exp_instrComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Exp_instr"-------
while continueRoutine:
    # get current time
    t = Exp_instrClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *begin* updates
    if t >= 0.0 and begin.status == NOT_STARTED:
        # keep track of start time/frame for later
        begin.tStart = t
        begin.frameNStart = frameN  # exact frame index
        begin.setAutoDraw(True)
    
    # *begin_exp_response* updates
    if t >= 0.0 and begin_exp_response.status == NOT_STARTED:
        # keep track of start time/frame for later
        begin_exp_response.tStart = t
        begin_exp_response.frameNStart = frameN  # exact frame index
        begin_exp_response.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(begin_exp_response.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if begin_exp_response.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            begin_exp_response.keys = theseKeys[-1]  # just the last key pressed
            begin_exp_response.rt = begin_exp_response.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Exp_instrComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Exp_instr"-------
for thisComponent in Exp_instrComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if begin_exp_response.keys in ['', [], None]:  # No response was made
    begin_exp_response.keys=None
thisExp.addData('begin_exp_response.keys',begin_exp_response.keys)
if begin_exp_response.keys != None:  # we had a response
    thisExp.addData('begin_exp_response.rt', begin_exp_response.rt)
thisExp.nextEntry()
# the Routine "Exp_instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials1 = data.TrialHandler(nReps=6, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Simon_stimuli_file.xlsx'),
    seed=None, name='trials1')
thisExp.addLoop(trials1)  # add the loop to the experiment
thisTrials1 = trials1.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrials1.rgb)
if thisTrials1 != None:
    for paramName in thisTrials1.keys():
        exec(paramName + '= thisTrials1.' + paramName)

for thisTrials1 in trials1:
    currentLoop = trials1
    # abbreviate parameter names if possible (e.g. rgb = thisTrials1.rgb)
    if thisTrials1 != None:
        for paramName in thisTrials1.keys():
            exec(paramName + '= thisTrials1.' + paramName)
    
    # ------Prepare to start Routine "ISI"-------
    t = 0
    ISIClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(0.200000)
    # update component parameters for each repeat
    # keep track of which components have finished
    ISIComponents = [blank]
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "ISI"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = ISIClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *blank* updates
        if t >= 0.0 and blank.status == NOT_STARTED:
            # keep track of start time/frame for later
            blank.tStart = t
            blank.frameNStart = frameN  # exact frame index
            blank.setAutoDraw(True)
        frameRemains = 0.0 + 0.2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if blank.status == STARTED and t >= frameRemains:
            blank.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ISIComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ISI"-------
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # ------Prepare to start Routine "trials"-------
    t = 0
    trialsClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    Exp_target.setColor(targetcolour, colorSpace='rgb')
    Exp_target.setPos((targetx,targety))
    Trial_response = event.BuilderKeyResponse()
    # keep track of which components have finished
    trialsComponents = [Fixation2, Exp_target, Trial_response]
    for thisComponent in trialsComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "trials"-------
    while continueRoutine:
        # get current time
        t = trialsClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Fixation2* updates
        if t >= 1 and Fixation2.status == NOT_STARTED:
            # keep track of start time/frame for later
            Fixation2.tStart = t
            Fixation2.frameNStart = frameN  # exact frame index
            Fixation2.setAutoDraw(True)
        
        # *Exp_target* updates
        if t >= 1 and Exp_target.status == NOT_STARTED:
            # keep track of start time/frame for later
            Exp_target.tStart = t
            Exp_target.frameNStart = frameN  # exact frame index
            Exp_target.setAutoDraw(True)
        
        # *Trial_response* updates
        if t >= 1 and Trial_response.status == NOT_STARTED:
            # keep track of start time/frame for later
            Trial_response.tStart = t
            Trial_response.frameNStart = frameN  # exact frame index
            Trial_response.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(Trial_response.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if Trial_response.status == STARTED:
            theseKeys = event.getKeys(keyList=['z', 'm'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                Trial_response.keys = theseKeys[-1]  # just the last key pressed
                Trial_response.rt = Trial_response.clock.getTime()
                # was this 'correct'?
                if (Trial_response.keys == str(corrAns)) or (Trial_response.keys == corrAns):
                    Trial_response.corr = 1
                else:
                    Trial_response.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialsComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "trials"-------
    for thisComponent in trialsComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if Trial_response.keys in ['', [], None]:  # No response was made
        Trial_response.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           Trial_response.corr = 1  # correct non-response
        else:
           Trial_response.corr = 0  # failed to respond (incorrectly)
    # store data for trials1 (TrialHandler)
    trials1.addData('Trial_response.keys',Trial_response.keys)
    trials1.addData('Trial_response.corr', Trial_response.corr)
    if Trial_response.keys != None:  # we had a response
        trials1.addData('Trial_response.rt', Trial_response.rt)
    # the Routine "trials" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 6 repeats of 'trials1'

# get names of stimulus parameters
if trials1.trialList in ([], [None], None):
    params = []
else:
    params = trials1.trialList[0].keys()
# save data for this loop
trials1.saveAsExcel(filename + '.xlsx', sheetName='trials1',
    stimOut=params,
    dataOut=['n','all_mean','all_std', 'all_raw'])

# ------Prepare to start Routine "pause"-------
t = 0
pauseClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
Continue = event.BuilderKeyResponse()
# keep track of which components have finished
pauseComponents = [text, Continue]
for thisComponent in pauseComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "pause"-------
while continueRoutine:
    # get current time
    t = pauseClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if t >= 0.0 and text.status == NOT_STARTED:
        # keep track of start time/frame for later
        text.tStart = t
        text.frameNStart = frameN  # exact frame index
        text.setAutoDraw(True)
    
    # *Continue* updates
    if t >= 0.0 and Continue.status == NOT_STARTED:
        # keep track of start time/frame for later
        Continue.tStart = t
        Continue.frameNStart = frameN  # exact frame index
        Continue.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(Continue.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if Continue.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            Continue.keys = theseKeys[-1]  # just the last key pressed
            Continue.rt = Continue.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in pauseComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "pause"-------
for thisComponent in pauseComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if Continue.keys in ['', [], None]:  # No response was made
    Continue.keys=None
thisExp.addData('Continue.keys',Continue.keys)
if Continue.keys != None:  # we had a response
    thisExp.addData('Continue.rt', Continue.rt)
thisExp.nextEntry()
# the Routine "pause" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials2 = data.TrialHandler(nReps=6, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Simon_stimuli_file.xlsx'),
    seed=None, name='trials2')
thisExp.addLoop(trials2)  # add the loop to the experiment
thisTrials2 = trials2.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrials2.rgb)
if thisTrials2 != None:
    for paramName in thisTrials2.keys():
        exec(paramName + '= thisTrials2.' + paramName)

for thisTrials2 in trials2:
    currentLoop = trials2
    # abbreviate parameter names if possible (e.g. rgb = thisTrials2.rgb)
    if thisTrials2 != None:
        for paramName in thisTrials2.keys():
            exec(paramName + '= thisTrials2.' + paramName)
    
    # ------Prepare to start Routine "ISI"-------
    t = 0
    ISIClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(0.200000)
    # update component parameters for each repeat
    # keep track of which components have finished
    ISIComponents = [blank]
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "ISI"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = ISIClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *blank* updates
        if t >= 0.0 and blank.status == NOT_STARTED:
            # keep track of start time/frame for later
            blank.tStart = t
            blank.frameNStart = frameN  # exact frame index
            blank.setAutoDraw(True)
        frameRemains = 0.0 + 0.2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if blank.status == STARTED and t >= frameRemains:
            blank.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ISIComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ISI"-------
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # ------Prepare to start Routine "trials"-------
    t = 0
    trialsClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    Exp_target.setColor(targetcolour, colorSpace='rgb')
    Exp_target.setPos((targetx,targety))
    Trial_response = event.BuilderKeyResponse()
    # keep track of which components have finished
    trialsComponents = [Fixation2, Exp_target, Trial_response]
    for thisComponent in trialsComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "trials"-------
    while continueRoutine:
        # get current time
        t = trialsClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Fixation2* updates
        if t >= 1 and Fixation2.status == NOT_STARTED:
            # keep track of start time/frame for later
            Fixation2.tStart = t
            Fixation2.frameNStart = frameN  # exact frame index
            Fixation2.setAutoDraw(True)
        
        # *Exp_target* updates
        if t >= 1 and Exp_target.status == NOT_STARTED:
            # keep track of start time/frame for later
            Exp_target.tStart = t
            Exp_target.frameNStart = frameN  # exact frame index
            Exp_target.setAutoDraw(True)
        
        # *Trial_response* updates
        if t >= 1 and Trial_response.status == NOT_STARTED:
            # keep track of start time/frame for later
            Trial_response.tStart = t
            Trial_response.frameNStart = frameN  # exact frame index
            Trial_response.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(Trial_response.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if Trial_response.status == STARTED:
            theseKeys = event.getKeys(keyList=['z', 'm'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                Trial_response.keys = theseKeys[-1]  # just the last key pressed
                Trial_response.rt = Trial_response.clock.getTime()
                # was this 'correct'?
                if (Trial_response.keys == str(corrAns)) or (Trial_response.keys == corrAns):
                    Trial_response.corr = 1
                else:
                    Trial_response.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialsComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "trials"-------
    for thisComponent in trialsComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if Trial_response.keys in ['', [], None]:  # No response was made
        Trial_response.keys=None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           Trial_response.corr = 1  # correct non-response
        else:
           Trial_response.corr = 0  # failed to respond (incorrectly)
    # store data for trials2 (TrialHandler)
    trials2.addData('Trial_response.keys',Trial_response.keys)
    trials2.addData('Trial_response.corr', Trial_response.corr)
    if Trial_response.keys != None:  # we had a response
        trials2.addData('Trial_response.rt', Trial_response.rt)
    # the Routine "trials" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 6 repeats of 'trials2'

# get names of stimulus parameters
if trials2.trialList in ([], [None], None):
    params = []
else:
    params = trials2.trialList[0].keys()
# save data for this loop
trials2.saveAsExcel(filename + '.xlsx', sheetName='trials2',
    stimOut=params,
    dataOut=['n','all_mean','all_std', 'all_raw'])

# ------Prepare to start Routine "End"-------
t = 0
EndClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
EndComponents = [stop]
for thisComponent in EndComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "End"-------
while continueRoutine:
    # get current time
    t = EndClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *stop* updates
    if t >= 0.0 and stop.status == NOT_STARTED:
        # keep track of start time/frame for later
        stop.tStart = t
        stop.frameNStart = frameN  # exact frame index
        stop.setAutoDraw(True)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in EndComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "End"-------
for thisComponent in EndComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "End" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()
# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
