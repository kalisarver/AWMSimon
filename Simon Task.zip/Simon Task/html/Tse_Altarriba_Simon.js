﻿/**************************** 
 * Tse_Altarriba_Simon Test *
 ****************************/

import { PsychoJS } from 'https://pavlovia.org/lib/core-3.2.js';
import * as core from 'https://pavlovia.org/lib/core-3.2.js';
import { TrialHandler } from 'https://pavlovia.org/lib/data-3.2.js';
import { Scheduler } from 'https://pavlovia.org/lib/util-3.2.js';
import * as util from 'https://pavlovia.org/lib/util-3.2.js';
import * as visual from 'https://pavlovia.org/lib/visual-3.2.js';
import { Sound } from 'https://pavlovia.org/lib/sound-3.2.js';

// init psychoJS:
var psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([(- 1), (- 1), (- 1)]),
  units: 'height',
  waitBlanking: true
});

// store info about the experiment session:
let expName = 'Tse_Altarriba_Simon';  // from the Builder filename that created this script
let expInfo = {'session': '001', 'participant': ''};

// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(Initial_instructionRoutineBegin);
flowScheduler.add(Initial_instructionRoutineEachFrame);
flowScheduler.add(Initial_instructionRoutineEnd);
flowScheduler.add(Expt_InstructionsRoutineBegin);
flowScheduler.add(Expt_InstructionsRoutineEachFrame);
flowScheduler.add(Expt_InstructionsRoutineEnd);
const Practice_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(Practice_loopLoopBegin, Practice_loopLoopScheduler);
flowScheduler.add(Practice_loopLoopScheduler);
flowScheduler.add(Practice_loopLoopEnd);
flowScheduler.add(Begin_ExperimentRoutineBegin);
flowScheduler.add(Begin_ExperimentRoutineEachFrame);
flowScheduler.add(Begin_ExperimentRoutineEnd);
const trialsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trialsLoopBegin, trialsLoopScheduler);
flowScheduler.add(trialsLoopScheduler);
flowScheduler.add(trialsLoopEnd);
flowScheduler.add(BreakRoutineBegin);
flowScheduler.add(BreakRoutineEachFrame);
flowScheduler.add(BreakRoutineEnd);
const trials_2LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trials_2LoopBegin, trials_2LoopScheduler);
flowScheduler.add(trials_2LoopScheduler);
flowScheduler.add(trials_2LoopEnd);
flowScheduler.add(ThanksRoutineBegin);
flowScheduler.add(ThanksRoutineEachFrame);
flowScheduler.add(ThanksRoutineEnd);
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({expName, expInfo});

var frameDur;
function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '3.2.4';
  expInfo['OS'] = window.navigator.platform;

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0/Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0/60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  
  return Scheduler.Event.NEXT;
}

var Initial_instructionClock;
var initialinstr;
var Space1;
var Expt_InstructionsClock;
var exptinstr;
var Space2;
var PracticeFixClock;
var imageFix;
var PracticeTrialsClock;
var imagePractice;
var key_resp;
var Begin_ExperimentClock;
var text;
var Space3;
var ExperimentFixClock;
var imageFixation;
var ExpTrialsClock;
var imageTrials;
var key_resp_2;
var BreakClock;
var text_2;
var Space4;
var ThanksClock;
var TheEnd;
var globalClock;
var routineTimer;
function experimentInit() {
  // Initialize components for Routine "Initial_instruction"
  Initial_instructionClock = new util.Clock();
  initialinstr = new visual.TextStim({
    win: psychoJS.window,
    name: 'initialinstr',
    text: 'The experiment is about to begin.\nPress the space bar for the instructions.',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.07,  wrapWidth: undefined, ori: 0,
    color: new util.Color('pink'),  opacity: 1,
    depth: 0.0 
  });
  
  Space1 = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Expt_Instructions"
  Expt_InstructionsClock = new util.Clock();
  exptinstr = new visual.TextStim({
    win: psychoJS.window,
    name: 'exptinstr',
    text: 'On each trial, you will see an arrow.\nYour job is to decide which direction the arrow is pointing to.\nIf the arrow is pointing to the RIGHT, press M\nIf the arrow is pointing to the LEFT, press Z\nIgnore the location, just focus on the direction.\nWe will start with a few practice trials.\nPress the space bar to continue.',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0,
    color: new util.Color('pink'),  opacity: 1,
    depth: 0.0 
  });
  
  Space2 = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "PracticeFix"
  PracticeFixClock = new util.Clock();
  imageFix = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imageFix', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [1, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  // Initialize components for Routine "PracticeTrials"
  PracticeTrialsClock = new util.Clock();
  imagePractice = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imagePractice', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [2, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  key_resp = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Begin_Experiment"
  Begin_ExperimentClock = new util.Clock();
  text = new visual.TextStim({
    win: psychoJS.window,
    name: 'text',
    text: 'Practice over. Are you ready to start the experiment?\nRemember to pay attention only to the direction that the arrow is pointing to!\nYou will not get feedback from now on.\nPress the space bar when you are ready.',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.07,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  Space3 = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "ExperimentFix"
  ExperimentFixClock = new util.Clock();
  imageFixation = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imageFixation', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [1, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  // Initialize components for Routine "ExpTrials"
  ExpTrialsClock = new util.Clock();
  imageTrials = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imageTrials', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [2, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  key_resp_2 = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Break"
  BreakClock = new util.Clock();
  text_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_2',
    text: 'Take a little break and press the space bar when you are ready to continue',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.07,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  Space4 = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "ExperimentFix"
  ExperimentFixClock = new util.Clock();
  imageFixation = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imageFixation', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [1, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  // Initialize components for Routine "ExpTrials"
  ExpTrialsClock = new util.Clock();
  imageTrials = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imageTrials', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [2, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  key_resp_2 = new core.Keyboard({psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Thanks"
  ThanksClock = new util.Clock();
  TheEnd = new visual.TextStim({
    win: psychoJS.window,
    name: 'TheEnd',
    text: 'All done. Thank you!',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.07,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}

var t;
var frameN;
var Initial_instructionComponents;
function Initial_instructionRoutineBegin() {
  //------Prepare to start Routine 'Initial_instruction'-------
  t = 0;
  Initial_instructionClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  Space1.keys = undefined;
  Space1.rt = undefined;
  // keep track of which components have finished
  Initial_instructionComponents = [];
  Initial_instructionComponents.push(initialinstr);
  Initial_instructionComponents.push(Space1);
  
  for (const thisComponent of Initial_instructionComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}

var continueRoutine;
function Initial_instructionRoutineEachFrame() {
  //------Loop for each frame of Routine 'Initial_instruction'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Initial_instructionClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *initialinstr* updates
  if (t >= 0.0 && initialinstr.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    initialinstr.tStart = t;  // (not accounting for frame time here)
    initialinstr.frameNStart = frameN;  // exact frame index
    initialinstr.setAutoDraw(true);
  }

  
  // *Space1* updates
  if (t >= 0.0 && Space1.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Space1.tStart = t;  // (not accounting for frame time here)
    Space1.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { Space1.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { Space1.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { Space1.clearEvents(); });
  }

  if (Space1.status === PsychoJS.Status.STARTED) {
    let theseKeys = Space1.getKeys({keyList: ['space'], waitRelease: false});
    
    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escape') {
      psychoJS.experiment.experimentEnded = true;
    }
    
    if (theseKeys.length > 0) {  // at least one key was pressed
      Space1.keys = theseKeys[0].name;  // just the last key pressed
      Space1.rt = theseKeys[0].rt;
      // a response ends the routine
      continueRoutine = false;
    }
  }
  
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Initial_instructionComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Initial_instructionRoutineEnd() {
  //------Ending Routine 'Initial_instruction'-------
  for (const thisComponent of Initial_instructionComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('Space1.keys', Space1.keys);
  if (typeof Space1.keys !== undefined) {  // we had a response
      psychoJS.experiment.addData('Space1.rt', Space1.rt);
      routineTimer.reset();
      }
  
  Space1.stop();
  // the Routine "Initial_instruction" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var Expt_InstructionsComponents;
function Expt_InstructionsRoutineBegin() {
  //------Prepare to start Routine 'Expt_Instructions'-------
  t = 0;
  Expt_InstructionsClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  Space2.keys = undefined;
  Space2.rt = undefined;
  // keep track of which components have finished
  Expt_InstructionsComponents = [];
  Expt_InstructionsComponents.push(exptinstr);
  Expt_InstructionsComponents.push(Space2);
  
  for (const thisComponent of Expt_InstructionsComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function Expt_InstructionsRoutineEachFrame() {
  //------Loop for each frame of Routine 'Expt_Instructions'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Expt_InstructionsClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *exptinstr* updates
  if (t >= 0.0 && exptinstr.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    exptinstr.tStart = t;  // (not accounting for frame time here)
    exptinstr.frameNStart = frameN;  // exact frame index
    exptinstr.setAutoDraw(true);
  }

  
  // *Space2* updates
  if (t >= 0.0 && Space2.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Space2.tStart = t;  // (not accounting for frame time here)
    Space2.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { Space2.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { Space2.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { Space2.clearEvents(); });
  }

  if (Space2.status === PsychoJS.Status.STARTED) {
    let theseKeys = Space2.getKeys({keyList: ['space'], waitRelease: false});
    
    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escape') {
      psychoJS.experiment.experimentEnded = true;
    }
    
    if (theseKeys.length > 0) {  // at least one key was pressed
      Space2.keys = theseKeys[0].name;  // just the last key pressed
      Space2.rt = theseKeys[0].rt;
      // a response ends the routine
      continueRoutine = false;
    }
  }
  
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Expt_InstructionsComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Expt_InstructionsRoutineEnd() {
  //------Ending Routine 'Expt_Instructions'-------
  for (const thisComponent of Expt_InstructionsComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('Space2.keys', Space2.keys);
  if (typeof Space2.keys !== undefined) {  // we had a response
      psychoJS.experiment.addData('Space2.rt', Space2.rt);
      routineTimer.reset();
      }
  
  Space2.stop();
  // the Routine "Expt_Instructions" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var Practice_loop;
var currentLoop;
function Practice_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  Practice_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'SimonPractice.xlsx',
    seed: undefined, name: 'Practice_loop'});
  psychoJS.experiment.addLoop(Practice_loop); // add the loop to the experiment
  currentLoop = Practice_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisPractice_loop of Practice_loop) {
    thisScheduler.add(importConditions(Practice_loop));
    thisScheduler.add(PracticeFixRoutineBegin);
    thisScheduler.add(PracticeFixRoutineEachFrame);
    thisScheduler.add(PracticeFixRoutineEnd);
    thisScheduler.add(PracticeTrialsRoutineBegin);
    thisScheduler.add(PracticeTrialsRoutineEachFrame);
    thisScheduler.add(PracticeTrialsRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}


function Practice_loopLoopEnd() {
  psychoJS.experiment.removeLoop(Practice_loop);

  return Scheduler.Event.NEXT;
}

var trials;
function trialsLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  trials = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'SimonStimuli.xlsx',
    seed: undefined, name: 'trials'});
  psychoJS.experiment.addLoop(trials); // add the loop to the experiment
  currentLoop = trials;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisTrial of trials) {
    thisScheduler.add(importConditions(trials));
    thisScheduler.add(ExperimentFixRoutineBegin);
    thisScheduler.add(ExperimentFixRoutineEachFrame);
    thisScheduler.add(ExperimentFixRoutineEnd);
    thisScheduler.add(ExpTrialsRoutineBegin);
    thisScheduler.add(ExpTrialsRoutineEachFrame);
    thisScheduler.add(ExpTrialsRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}


function trialsLoopEnd() {
  psychoJS.experiment.removeLoop(trials);

  return Scheduler.Event.NEXT;
}

var trials_2;
function trials_2LoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  trials_2 = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'SimonStimuli.xlsx',
    seed: undefined, name: 'trials_2'});
  psychoJS.experiment.addLoop(trials_2); // add the loop to the experiment
  currentLoop = trials_2;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisTrial_2 of trials_2) {
    thisScheduler.add(importConditions(trials_2));
    thisScheduler.add(ExperimentFixRoutineBegin);
    thisScheduler.add(ExperimentFixRoutineEachFrame);
    thisScheduler.add(ExperimentFixRoutineEnd);
    thisScheduler.add(ExpTrialsRoutineBegin);
    thisScheduler.add(ExpTrialsRoutineEachFrame);
    thisScheduler.add(ExpTrialsRoutineEnd);
    thisScheduler.add(endLoopIteration({thisScheduler, isTrials : true}));
  }

  return Scheduler.Event.NEXT;
}


function trials_2LoopEnd() {
  psychoJS.experiment.removeLoop(trials_2);

  return Scheduler.Event.NEXT;
}

var PracticeFixComponents;
function PracticeFixRoutineBegin() {
  //------Prepare to start Routine 'PracticeFix'-------
  t = 0;
  PracticeFixClock.reset(); // clock
  frameN = -1;
  routineTimer.add(1.250000);
  // update component parameters for each repeat
  imageFix.setImage('Fixation.jpeg');
  // keep track of which components have finished
  PracticeFixComponents = [];
  PracticeFixComponents.push(imageFix);
  
  for (const thisComponent of PracticeFixComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}

var frameRemains;
function PracticeFixRoutineEachFrame() {
  //------Loop for each frame of Routine 'PracticeFix'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = PracticeFixClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *imageFix* updates
  if (t >= 0.75 && imageFix.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    imageFix.tStart = t;  // (not accounting for frame time here)
    imageFix.frameNStart = frameN;  // exact frame index
    imageFix.setAutoDraw(true);
  }

  frameRemains = 0.75 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (imageFix.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    imageFix.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of PracticeFixComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function PracticeFixRoutineEnd() {
  //------Ending Routine 'PracticeFix'-------
  for (const thisComponent of PracticeFixComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var PracticeTrialsComponents;
function PracticeTrialsRoutineBegin() {
  //------Prepare to start Routine 'PracticeTrials'-------
  t = 0;
  PracticeTrialsClock.reset(); // clock
  frameN = -1;
  routineTimer.add(4.000000);
  // update component parameters for each repeat
  imagePractice.setImage(ImageFile);
  key_resp.keys = undefined;
  key_resp.rt = undefined;
  // keep track of which components have finished
  PracticeTrialsComponents = [];
  PracticeTrialsComponents.push(imagePractice);
  PracticeTrialsComponents.push(key_resp);
  
  for (const thisComponent of PracticeTrialsComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function PracticeTrialsRoutineEachFrame() {
  //------Loop for each frame of Routine 'PracticeTrials'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = PracticeTrialsClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *imagePractice* updates
  if (t >= 0.0 && imagePractice.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    imagePractice.tStart = t;  // (not accounting for frame time here)
    imagePractice.frameNStart = frameN;  // exact frame index
    imagePractice.setAutoDraw(true);
  }

  frameRemains = 0.0 + 4 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (imagePractice.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    imagePractice.setAutoDraw(false);
  }
  
  // *key_resp* updates
  if (t >= 0.0 && key_resp.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    key_resp.tStart = t;  // (not accounting for frame time here)
    key_resp.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { key_resp.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { key_resp.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { key_resp.clearEvents(); });
  }

  frameRemains = 0.0 + 4 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (key_resp.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    key_resp.status = PsychoJS.Status.FINISHED;
  }

  if (key_resp.status === PsychoJS.Status.STARTED) {
    let theseKeys = key_resp.getKeys({keyList: ['m', 'z'], waitRelease: false});
    
    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escape') {
      psychoJS.experiment.experimentEnded = true;
    }
    
    if (theseKeys.length > 0) {  // at least one key was pressed
      if (key_resp.keys === undefined) {  // then this was the first keypress
        key_resp.keys = theseKeys[0].name;  // just the first key pressed
        key_resp.rt = theseKeys[0].rt;
        // was this 'correct'?
        if (key_resp.keys === CorrAns) {
            key_resp.corr = 1;
        } else {
            key_resp.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
  }
  
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of PracticeTrialsComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function PracticeTrialsRoutineEnd() {
  //------Ending Routine 'PracticeTrials'-------
  for (const thisComponent of PracticeTrialsComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  // was no response the correct answer?!
  if (key_resp.keys === undefined) {
    if (['None','none',undefined].includes(CorrAns)) {
       key_resp.corr = 1  // correct non-response
    } else {
       key_resp.corr = 0  // failed to respond (incorrectly)
    }
  }
  // store data for thisExp (ExperimentHandler)
  psychoJS.experiment.addData('key_resp.keys', key_resp.keys);
  psychoJS.experiment.addData('key_resp.corr', key_resp.corr);
  if (typeof key_resp.keys !== undefined) {  // we had a response
      psychoJS.experiment.addData('key_resp.rt', key_resp.rt);
      routineTimer.reset();
      }
  
  key_resp.stop();
  return Scheduler.Event.NEXT;
}

var Begin_ExperimentComponents;
function Begin_ExperimentRoutineBegin() {
  //------Prepare to start Routine 'Begin_Experiment'-------
  t = 0;
  Begin_ExperimentClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  Space3.keys = undefined;
  Space3.rt = undefined;
  // keep track of which components have finished
  Begin_ExperimentComponents = [];
  Begin_ExperimentComponents.push(text);
  Begin_ExperimentComponents.push(Space3);
  
  for (const thisComponent of Begin_ExperimentComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function Begin_ExperimentRoutineEachFrame() {
  //------Loop for each frame of Routine 'Begin_Experiment'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = Begin_ExperimentClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *text* updates
  if (t >= 0.0 && text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    text.tStart = t;  // (not accounting for frame time here)
    text.frameNStart = frameN;  // exact frame index
    text.setAutoDraw(true);
  }

  
  // *Space3* updates
  if (t >= 0.0 && Space3.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Space3.tStart = t;  // (not accounting for frame time here)
    Space3.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { Space3.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { Space3.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { Space3.clearEvents(); });
  }

  if (Space3.status === PsychoJS.Status.STARTED) {
    let theseKeys = Space3.getKeys({keyList: ['space'], waitRelease: false});
    
    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escape') {
      psychoJS.experiment.experimentEnded = true;
    }
    
    if (theseKeys.length > 0) {  // at least one key was pressed
      Space3.keys = theseKeys[0].name;  // just the last key pressed
      Space3.rt = theseKeys[0].rt;
      // a response ends the routine
      continueRoutine = false;
    }
  }
  
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of Begin_ExperimentComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function Begin_ExperimentRoutineEnd() {
  //------Ending Routine 'Begin_Experiment'-------
  for (const thisComponent of Begin_ExperimentComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('Space3.keys', Space3.keys);
  if (typeof Space3.keys !== undefined) {  // we had a response
      psychoJS.experiment.addData('Space3.rt', Space3.rt);
      routineTimer.reset();
      }
  
  Space3.stop();
  // the Routine "Begin_Experiment" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var ExperimentFixComponents;
function ExperimentFixRoutineBegin() {
  //------Prepare to start Routine 'ExperimentFix'-------
  t = 0;
  ExperimentFixClock.reset(); // clock
  frameN = -1;
  routineTimer.add(1.250000);
  // update component parameters for each repeat
  imageFixation.setImage('Fixation.jpeg');
  // keep track of which components have finished
  ExperimentFixComponents = [];
  ExperimentFixComponents.push(imageFixation);
  
  for (const thisComponent of ExperimentFixComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function ExperimentFixRoutineEachFrame() {
  //------Loop for each frame of Routine 'ExperimentFix'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = ExperimentFixClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *imageFixation* updates
  if (t >= 0.75 && imageFixation.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    imageFixation.tStart = t;  // (not accounting for frame time here)
    imageFixation.frameNStart = frameN;  // exact frame index
    imageFixation.setAutoDraw(true);
  }

  frameRemains = 0.75 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (imageFixation.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    imageFixation.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of ExperimentFixComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function ExperimentFixRoutineEnd() {
  //------Ending Routine 'ExperimentFix'-------
  for (const thisComponent of ExperimentFixComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}

var ExpTrialsComponents;
function ExpTrialsRoutineBegin() {
  //------Prepare to start Routine 'ExpTrials'-------
  t = 0;
  ExpTrialsClock.reset(); // clock
  frameN = -1;
  routineTimer.add(4.000000);
  // update component parameters for each repeat
  imageTrials.setImage(ImageFile);
  key_resp_2.keys = undefined;
  key_resp_2.rt = undefined;
  // keep track of which components have finished
  ExpTrialsComponents = [];
  ExpTrialsComponents.push(imageTrials);
  ExpTrialsComponents.push(key_resp_2);
  
  for (const thisComponent of ExpTrialsComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function ExpTrialsRoutineEachFrame() {
  //------Loop for each frame of Routine 'ExpTrials'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = ExpTrialsClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *imageTrials* updates
  if (t >= 0.0 && imageTrials.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    imageTrials.tStart = t;  // (not accounting for frame time here)
    imageTrials.frameNStart = frameN;  // exact frame index
    imageTrials.setAutoDraw(true);
  }

  frameRemains = 0.0 + 4 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (imageTrials.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    imageTrials.setAutoDraw(false);
  }
  
  // *key_resp_2* updates
  if (t >= 0.0 && key_resp_2.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    key_resp_2.tStart = t;  // (not accounting for frame time here)
    key_resp_2.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { key_resp_2.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { key_resp_2.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { key_resp_2.clearEvents(); });
  }

  frameRemains = 0.0 + 4 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (key_resp_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    key_resp_2.status = PsychoJS.Status.FINISHED;
  }

  if (key_resp_2.status === PsychoJS.Status.STARTED) {
    let theseKeys = key_resp_2.getKeys({keyList: ['m', 'z'], waitRelease: false});
    
    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escape') {
      psychoJS.experiment.experimentEnded = true;
    }
    
    if (theseKeys.length > 0) {  // at least one key was pressed
      if (key_resp_2.keys === undefined) {  // then this was the first keypress
        key_resp_2.keys = theseKeys[0].name;  // just the first key pressed
        key_resp_2.rt = theseKeys[0].rt;
        // was this 'correct'?
        if (key_resp_2.keys === CorrAns) {
            key_resp_2.corr = 1;
        } else {
            key_resp_2.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
  }
  
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of ExpTrialsComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function ExpTrialsRoutineEnd() {
  //------Ending Routine 'ExpTrials'-------
  for (const thisComponent of ExpTrialsComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  // was no response the correct answer?!
  if (key_resp_2.keys === undefined) {
    if (['None','none',undefined].includes(CorrAns)) {
       key_resp_2.corr = 1  // correct non-response
    } else {
       key_resp_2.corr = 0  // failed to respond (incorrectly)
    }
  }
  // store data for thisExp (ExperimentHandler)
  psychoJS.experiment.addData('key_resp_2.keys', key_resp_2.keys);
  psychoJS.experiment.addData('key_resp_2.corr', key_resp_2.corr);
  if (typeof key_resp_2.keys !== undefined) {  // we had a response
      psychoJS.experiment.addData('key_resp_2.rt', key_resp_2.rt);
      routineTimer.reset();
      }
  
  key_resp_2.stop();
  return Scheduler.Event.NEXT;
}

var BreakComponents;
function BreakRoutineBegin() {
  //------Prepare to start Routine 'Break'-------
  t = 0;
  BreakClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  Space4.keys = undefined;
  Space4.rt = undefined;
  // keep track of which components have finished
  BreakComponents = [];
  BreakComponents.push(text_2);
  BreakComponents.push(Space4);
  
  for (const thisComponent of BreakComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function BreakRoutineEachFrame() {
  //------Loop for each frame of Routine 'Break'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = BreakClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *text_2* updates
  if (t >= 0.0 && text_2.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    text_2.tStart = t;  // (not accounting for frame time here)
    text_2.frameNStart = frameN;  // exact frame index
    text_2.setAutoDraw(true);
  }

  
  // *Space4* updates
  if (t >= 0.0 && Space4.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Space4.tStart = t;  // (not accounting for frame time here)
    Space4.frameNStart = frameN;  // exact frame index
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { Space4.clock.reset(); });  // t=0 on next screen flip
    psychoJS.window.callOnFlip(function() { Space4.start(); }); // start on screen flip
    psychoJS.window.callOnFlip(function() { Space4.clearEvents(); });
  }

  if (Space4.status === PsychoJS.Status.STARTED) {
    let theseKeys = Space4.getKeys({keyList: ['space'], waitRelease: false});
    
    // check for quit:
    if (theseKeys.length > 0 && theseKeys[0].name === 'escape') {
      psychoJS.experiment.experimentEnded = true;
    }
    
    if (theseKeys.length > 0) {  // at least one key was pressed
      Space4.keys = theseKeys[0].name;  // just the last key pressed
      Space4.rt = theseKeys[0].rt;
      // a response ends the routine
      continueRoutine = false;
    }
  }
  
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of BreakComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function BreakRoutineEnd() {
  //------Ending Routine 'Break'-------
  for (const thisComponent of BreakComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  psychoJS.experiment.addData('Space4.keys', Space4.keys);
  if (typeof Space4.keys !== undefined) {  // we had a response
      psychoJS.experiment.addData('Space4.rt', Space4.rt);
      routineTimer.reset();
      }
  
  Space4.stop();
  // the Routine "Break" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var ThanksComponents;
function ThanksRoutineBegin() {
  //------Prepare to start Routine 'Thanks'-------
  t = 0;
  ThanksClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  // keep track of which components have finished
  ThanksComponents = [];
  ThanksComponents.push(TheEnd);
  
  for (const thisComponent of ThanksComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function ThanksRoutineEachFrame() {
  //------Loop for each frame of Routine 'Thanks'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = ThanksClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *TheEnd* updates
  if (t >= 0.0 && TheEnd.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    TheEnd.tStart = t;  // (not accounting for frame time here)
    TheEnd.frameNStart = frameN;  // exact frame index
    TheEnd.setAutoDraw(true);
  }

  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of ThanksComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function ThanksRoutineEnd() {
  //------Ending Routine 'Thanks'-------
  for (const thisComponent of ThanksComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  // the Routine "Thanks" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}


function endLoopIteration({thisScheduler, isTrials=true}) {
  // ------Prepare for next entry------
  return function () {
    // ------Check if user ended loop early------
    if (currentLoop.finished) {
      // Check for and save orphaned data
      if (Object.keys(psychoJS.experiment._thisEntry).length > 0) {
        psychoJS.experiment.nextEntry();
      }
      thisScheduler.stop();
    } else if (isTrials) {
      psychoJS.experiment.nextEntry();
    }
  return Scheduler.Event.NEXT;
  };
}


function importConditions(loop) {
  const trialIndex = loop.getTrialIndex();
  return function () {
    loop.setTrialIndex(trialIndex);
    psychoJS.importAttributes(loop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (Object.keys(psychoJS.experiment._thisEntry).length > 0) {
    psychoJS.experiment.nextEntry();
  }
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});

  return Scheduler.Event.QUIT;
}
