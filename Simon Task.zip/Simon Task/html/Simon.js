﻿/************** 
 * Simon Test *
 **************/

import { core, data, sound, util, visual } from './lib/psychojs-2021.2.3.js';
const { PsychoJS } = core;
const { TrialHandler } = data;
const { Scheduler } = util;
//some handy aliases as in the psychopy scripts;
const { abs, sin, cos, PI: pi, sqrt } = Math;
const { round } = util;


// store info about the experiment session:
let expName = 'Simon';  // from the Builder filename that created this script
let expInfo = {'participant': ''};

// Start code blocks for 'Before Experiment'
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([(- 1), (- 1), (- 1)]),
  units: 'height',
  waitBlanking: true
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(Initial_instructionRoutineBegin());
flowScheduler.add(Initial_instructionRoutineEachFrame());
flowScheduler.add(Initial_instructionRoutineEnd());
flowScheduler.add(Expt_InstructionsRoutineBegin());
flowScheduler.add(Expt_InstructionsRoutineEachFrame());
flowScheduler.add(Expt_InstructionsRoutineEnd());
const Practice_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(Practice_loopLoopBegin(Practice_loopLoopScheduler));
flowScheduler.add(Practice_loopLoopScheduler);
flowScheduler.add(Practice_loopLoopEnd);
flowScheduler.add(ThanksRoutineBegin());
flowScheduler.add(ThanksRoutineEachFrame());
flowScheduler.add(ThanksRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  });

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.EXP);


var frameDur;
async function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2021.2.3';
  expInfo['OS'] = window.navigator.platform;

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  psychoJS.setRedirectUrls(('https://ucl-ioephd.sona-systems.com/webstudy_credit.aspx?experiment_id=28&credit_token=98436a24aed540768d32a20d28ab69fb&survey_code=' + expInfo['participant']), '');

  return Scheduler.Event.NEXT;
}


var Initial_instructionClock;
var initialinstr;
var Space1;
var Expt_InstructionsClock;
var exptinstr;
var Space2;
var FixationClock;
var imageFix;
var TrialsClock;
var imagePractice;
var response;
var ThanksClock;
var TheEnd;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "Initial_instruction"
  Initial_instructionClock = new util.Clock();
  initialinstr = new visual.TextStim({
    win: psychoJS.window,
    name: 'initialinstr',
    text: 'The experiment is about to begin.\nPress the space bar for the instructions.',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.07,  wrapWidth: undefined, ori: 0,
    color: new util.Color('pink'),  opacity: 1,
    depth: 0.0 
  });
  
  Space1 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Expt_Instructions"
  Expt_InstructionsClock = new util.Clock();
  exptinstr = new visual.TextStim({
    win: psychoJS.window,
    name: 'exptinstr',
    text: 'On each trial, you will see an arrow.\nYour job is to decide which direction the arrow is pointing to.\nIf the arrow is pointing to the RIGHT, press M\nIf the arrow is pointing to the LEFT, press Z\nIgnore the location, just focus on the direction.\nWe will start with a few practice trials.\nPress the space bar to continue.',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('pink'),  opacity: 1,
    depth: 0.0 
  });
  
  Space2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Fixation"
  FixationClock = new util.Clock();
  imageFix = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imageFix', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [1, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  // Initialize components for Routine "Trials"
  TrialsClock = new util.Clock();
  imagePractice = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imagePractice', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [1, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  response = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Thanks"
  ThanksClock = new util.Clock();
  TheEnd = new visual.TextStim({
    win: psychoJS.window,
    name: 'TheEnd',
    text: 'All done. Thank you!\nYou may now proceed to the next part of the study.',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.07,  wrapWidth: undefined, ori: 0,
    color: new util.Color('pink'),  opacity: 1,
    depth: 0.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var _Space1_allKeys;
var Initial_instructionComponents;
function Initial_instructionRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'Initial_instruction'-------
    t = 0;
    Initial_instructionClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    Space1.keys = undefined;
    Space1.rt = undefined;
    _Space1_allKeys = [];
    // keep track of which components have finished
    Initial_instructionComponents = [];
    Initial_instructionComponents.push(initialinstr);
    Initial_instructionComponents.push(Space1);
    
    for (const thisComponent of Initial_instructionComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function Initial_instructionRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'Initial_instruction'-------
    // get current time
    t = Initial_instructionClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *initialinstr* updates
    if (t >= 0.0 && initialinstr.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      initialinstr.tStart = t;  // (not accounting for frame time here)
      initialinstr.frameNStart = frameN;  // exact frame index
      
      initialinstr.setAutoDraw(true);
    }

    
    // *Space1* updates
    if (t >= 0.0 && Space1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Space1.tStart = t;  // (not accounting for frame time here)
      Space1.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { Space1.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { Space1.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { Space1.clearEvents(); });
    }

    if (Space1.status === PsychoJS.Status.STARTED) {
      let theseKeys = Space1.getKeys({keyList: ['space'], waitRelease: false});
      _Space1_allKeys = _Space1_allKeys.concat(theseKeys);
      if (_Space1_allKeys.length > 0) {
        Space1.keys = _Space1_allKeys[_Space1_allKeys.length - 1].name;  // just the last key pressed
        Space1.rt = _Space1_allKeys[_Space1_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of Initial_instructionComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function Initial_instructionRoutineEnd() {
  return async function () {
    //------Ending Routine 'Initial_instruction'-------
    for (const thisComponent of Initial_instructionComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('Space1.keys', Space1.keys);
    if (typeof Space1.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('Space1.rt', Space1.rt);
        routineTimer.reset();
        }
    
    Space1.stop();
    // the Routine "Initial_instruction" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _Space2_allKeys;
var Expt_InstructionsComponents;
function Expt_InstructionsRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'Expt_Instructions'-------
    t = 0;
    Expt_InstructionsClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    Space2.keys = undefined;
    Space2.rt = undefined;
    _Space2_allKeys = [];
    // keep track of which components have finished
    Expt_InstructionsComponents = [];
    Expt_InstructionsComponents.push(exptinstr);
    Expt_InstructionsComponents.push(Space2);
    
    for (const thisComponent of Expt_InstructionsComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function Expt_InstructionsRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'Expt_Instructions'-------
    // get current time
    t = Expt_InstructionsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *exptinstr* updates
    if (t >= 0.0 && exptinstr.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exptinstr.tStart = t;  // (not accounting for frame time here)
      exptinstr.frameNStart = frameN;  // exact frame index
      
      exptinstr.setAutoDraw(true);
    }

    
    // *Space2* updates
    if (t >= 0.0 && Space2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Space2.tStart = t;  // (not accounting for frame time here)
      Space2.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { Space2.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { Space2.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { Space2.clearEvents(); });
    }

    if (Space2.status === PsychoJS.Status.STARTED) {
      let theseKeys = Space2.getKeys({keyList: ['space'], waitRelease: false});
      _Space2_allKeys = _Space2_allKeys.concat(theseKeys);
      if (_Space2_allKeys.length > 0) {
        Space2.keys = _Space2_allKeys[_Space2_allKeys.length - 1].name;  // just the last key pressed
        Space2.rt = _Space2_allKeys[_Space2_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of Expt_InstructionsComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function Expt_InstructionsRoutineEnd() {
  return async function () {
    //------Ending Routine 'Expt_Instructions'-------
    for (const thisComponent of Expt_InstructionsComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('Space2.keys', Space2.keys);
    if (typeof Space2.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('Space2.rt', Space2.rt);
        routineTimer.reset();
        }
    
    Space2.stop();
    // the Routine "Expt_Instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var Practice_loop;
var currentLoop;
function Practice_loopLoopBegin(Practice_loopLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    Practice_loop = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 5, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'SimonPractice.xlsx',
      seed: undefined, name: 'Practice_loop'
    });
    psychoJS.experiment.addLoop(Practice_loop); // add the loop to the experiment
    currentLoop = Practice_loop;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisPractice_loop of Practice_loop) {
      const snapshot = Practice_loop.getSnapshot();
      Practice_loopLoopScheduler.add(importConditions(snapshot));
      Practice_loopLoopScheduler.add(FixationRoutineBegin(snapshot));
      Practice_loopLoopScheduler.add(FixationRoutineEachFrame());
      Practice_loopLoopScheduler.add(FixationRoutineEnd());
      Practice_loopLoopScheduler.add(TrialsRoutineBegin(snapshot));
      Practice_loopLoopScheduler.add(TrialsRoutineEachFrame());
      Practice_loopLoopScheduler.add(TrialsRoutineEnd());
      Practice_loopLoopScheduler.add(endLoopIteration(Practice_loopLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function Practice_loopLoopEnd() {
  psychoJS.experiment.removeLoop(Practice_loop);

  return Scheduler.Event.NEXT;
}


var FixationComponents;
function FixationRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'Fixation'-------
    t = 0;
    FixationClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.250000);
    // update component parameters for each repeat
    imageFix.setImage('Fixation.jpeg');
    // keep track of which components have finished
    FixationComponents = [];
    FixationComponents.push(imageFix);
    
    for (const thisComponent of FixationComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function FixationRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'Fixation'-------
    // get current time
    t = FixationClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *imageFix* updates
    if (t >= 0.75 && imageFix.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      imageFix.tStart = t;  // (not accounting for frame time here)
      imageFix.frameNStart = frameN;  // exact frame index
      
      imageFix.setAutoDraw(true);
    }

    frameRemains = 0.75 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (imageFix.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      imageFix.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of FixationComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function FixationRoutineEnd() {
  return async function () {
    //------Ending Routine 'Fixation'-------
    for (const thisComponent of FixationComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    return Scheduler.Event.NEXT;
  };
}


var _response_allKeys;
var TrialsComponents;
function TrialsRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'Trials'-------
    t = 0;
    TrialsClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(4.000000);
    // update component parameters for each repeat
    imagePractice.setImage(ImageFile);
    response.keys = undefined;
    response.rt = undefined;
    _response_allKeys = [];
    // keep track of which components have finished
    TrialsComponents = [];
    TrialsComponents.push(imagePractice);
    TrialsComponents.push(response);
    
    for (const thisComponent of TrialsComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function TrialsRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'Trials'-------
    // get current time
    t = TrialsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *imagePractice* updates
    if (t >= 0.0 && imagePractice.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      imagePractice.tStart = t;  // (not accounting for frame time here)
      imagePractice.frameNStart = frameN;  // exact frame index
      
      imagePractice.setAutoDraw(true);
    }

    frameRemains = 0.0 + 4 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (imagePractice.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      imagePractice.setAutoDraw(false);
    }
    
    // *response* updates
    if (t >= 0.0 && response.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      response.tStart = t;  // (not accounting for frame time here)
      response.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { response.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { response.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { response.clearEvents(); });
    }

    frameRemains = 0.0 + 4 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (response.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      response.status = PsychoJS.Status.FINISHED;
  }

    if (response.status === PsychoJS.Status.STARTED) {
      let theseKeys = response.getKeys({keyList: ['m', 'z'], waitRelease: false});
      _response_allKeys = _response_allKeys.concat(theseKeys);
      if (_response_allKeys.length > 0) {
        response.keys = _response_allKeys[0].name;  // just the first key pressed
        response.rt = _response_allKeys[0].rt;
        // was this correct?
        if (response.keys == CorrAns) {
            response.corr = 1;
        } else {
            response.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of TrialsComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function TrialsRoutineEnd() {
  return async function () {
    //------Ending Routine 'Trials'-------
    for (const thisComponent of TrialsComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // was no response the correct answer?!
    if (response.keys === undefined) {
      if (['None','none',undefined].includes(CorrAns)) {
         response.corr = 1;  // correct non-response
      } else {
         response.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for thisExp (ExperimentHandler)
    psychoJS.experiment.addData('response.keys', response.keys);
    psychoJS.experiment.addData('response.corr', response.corr);
    if (typeof response.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('response.rt', response.rt);
        routineTimer.reset();
        }
    
    response.stop();
    return Scheduler.Event.NEXT;
  };
}


var ThanksComponents;
function ThanksRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'Thanks'-------
    t = 0;
    ThanksClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(4.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    ThanksComponents = [];
    ThanksComponents.push(TheEnd);
    
    for (const thisComponent of ThanksComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function ThanksRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'Thanks'-------
    // get current time
    t = ThanksClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *TheEnd* updates
    if (t >= 0.0 && TheEnd.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      TheEnd.tStart = t;  // (not accounting for frame time here)
      TheEnd.frameNStart = frameN;  // exact frame index
      
      TheEnd.setAutoDraw(true);
    }

    frameRemains = 0.0 + 4 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (TheEnd.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      TheEnd.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of ThanksComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ThanksRoutineEnd() {
  return async function () {
    //------Ending Routine 'Thanks'-------
    for (const thisComponent of ThanksComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    return Scheduler.Event.NEXT;
  };
}


function endLoopIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        const thisTrial = snapshot.getCurrentTrial();
        if (typeof thisTrial === 'undefined' || !('isTrials' in thisTrial) || thisTrial.isTrials) {
          psychoJS.experiment.nextEntry(snapshot);
        }
      }
    return Scheduler.Event.NEXT;
    }
  };
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
