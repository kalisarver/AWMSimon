﻿/***************************** 
 * Tse_Altarriba_Simon1 Test *
 *****************************/

// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([(- 1), (- 1), (- 1)]),
  units: 'height',
  waitBlanking: true
});

// store info about the experiment session:
let expName = 'Tse_Altarriba_Simon1';  // from the Builder filename that created this script
let expInfo = {'Your initials': '', 'What is your age?': '', 'What is your gender?': '', 'What year are you in?': '', 'Are you Dyslexic? (Y/N)': '', 'Are you bi/multilingual? (Y/N)': '', 'What is your first language?': '', 'What is your second language? (if you are monollingual, leave blank)': '', 'What other languages do you speak?': ''};

// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(Initial_instructionRoutineBegin());
flowScheduler.add(Initial_instructionRoutineEachFrame());
flowScheduler.add(Initial_instructionRoutineEnd());
flowScheduler.add(Expt_InstructionsRoutineBegin());
flowScheduler.add(Expt_InstructionsRoutineEachFrame());
flowScheduler.add(Expt_InstructionsRoutineEnd());
const Practice_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(Practice_loopLoopBegin, Practice_loopLoopScheduler);
flowScheduler.add(Practice_loopLoopScheduler);
flowScheduler.add(Practice_loopLoopEnd);
flowScheduler.add(Begin_ExperimentRoutineBegin());
flowScheduler.add(Begin_ExperimentRoutineEachFrame());
flowScheduler.add(Begin_ExperimentRoutineEnd());
const trialsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trialsLoopBegin, trialsLoopScheduler);
flowScheduler.add(trialsLoopScheduler);
flowScheduler.add(trialsLoopEnd);
flowScheduler.add(BreakRoutineBegin());
flowScheduler.add(BreakRoutineEachFrame());
flowScheduler.add(BreakRoutineEnd());
const trials_2LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trials_2LoopBegin, trials_2LoopScheduler);
flowScheduler.add(trials_2LoopScheduler);
flowScheduler.add(trials_2LoopEnd);
flowScheduler.add(ThanksRoutineBegin());
flowScheduler.add(ThanksRoutineEachFrame());
flowScheduler.add(ThanksRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  });


var frameDur;
function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2020.1.2';
  expInfo['OS'] = window.navigator.platform;

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  psychoJS.setRedirectUrls(('https://ucl-ioephd.sona-systems.com/webstudy_credit.aspx?experiment_id=28&credit_token=98436a24aed540768d32a20d28ab69fb&survey_code=' + expInfo['participant']), '');

  return Scheduler.Event.NEXT;
}


var Initial_instructionClock;
var initialinstr;
var Space1;
var Expt_InstructionsClock;
var exptinstr;
var Space2;
var PracticeFixClock;
var imageFix;
var PracticeTrialsClock;
var imagePractice;
var response;
var FeedbackClock;
var Feedback_2;
var Begin_ExperimentClock;
var text;
var Space3;
var ExperimentFixClock;
var imageFixation;
var ExpTrialsClock;
var imageTrials;
var key_resp_2;
var BreakClock;
var text_2;
var Space4;
var ThanksClock;
var TheEnd;
var globalClock;
var routineTimer;
function experimentInit() {
  // Initialize components for Routine "Initial_instruction"
  Initial_instructionClock = new util.Clock();
  initialinstr = new visual.TextStim({
    win: psychoJS.window,
    name: 'initialinstr',
    text: 'The experiment is about to begin.\nPress the space bar for the instructions.',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.07,  wrapWidth: undefined, ori: 0,
    color: new util.Color('pink'),  opacity: 1,
    depth: 0.0 
  });
  
  Space1 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Expt_Instructions"
  Expt_InstructionsClock = new util.Clock();
  exptinstr = new visual.TextStim({
    win: psychoJS.window,
    name: 'exptinstr',
    text: 'On each trial, you will see an arrow.\nYour job is to decide which direction the arrow is pointing to.\nIf the arrow is pointing to the RIGHT, press M\nIf the arrow is pointing to the LEFT, press Z\nIgnore the location, just focus on the direction.\nWe will start with a few practice trials.\nPress the space bar to continue.',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('pink'),  opacity: 1,
    depth: 0.0 
  });
  
  Space2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "PracticeFix"
  PracticeFixClock = new util.Clock();
  imageFix = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imageFix', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [1, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  // Initialize components for Routine "PracticeTrials"
  PracticeTrialsClock = new util.Clock();
  imagePractice = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imagePractice', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [1, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  response = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Feedback"
  FeedbackClock = new util.Clock();
  Feedback_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'Feedback_2',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.07,  wrapWidth: undefined, ori: 0,
    color: new util.Color('pink'),  opacity: 1,
    depth: -1.0 
  });
  
  // Initialize components for Routine "Begin_Experiment"
  Begin_ExperimentClock = new util.Clock();
  text = new visual.TextStim({
    win: psychoJS.window,
    name: 'text',
    text: 'Practice over. Are you ready to start the experiment?\nRemember: If the arrow is pointing to the RIGHT, press M.\nIf the arrow is pointing to the LEFT, press Z.\nYou will not get feedback from now on.\nPress the space bar when you are ready.\nIf you no longer wish to participate, press esc. Your data will not be saved.',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.035,  wrapWidth: undefined, ori: 0,
    color: new util.Color('pink'),  opacity: 1,
    depth: 0.0 
  });
  
  Space3 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "ExperimentFix"
  ExperimentFixClock = new util.Clock();
  imageFixation = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imageFixation', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [1, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  // Initialize components for Routine "ExpTrials"
  ExpTrialsClock = new util.Clock();
  imageTrials = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imageTrials', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [1, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  key_resp_2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Break"
  BreakClock = new util.Clock();
  text_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_2',
    text: 'Take a little break and press the space bar when you are ready to continue',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.07,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  Space4 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "ExperimentFix"
  ExperimentFixClock = new util.Clock();
  imageFixation = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imageFixation', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [1, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  // Initialize components for Routine "ExpTrials"
  ExpTrialsClock = new util.Clock();
  imageTrials = new visual.ImageStim({
    win : psychoJS.window,
    name : 'imageTrials', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0, pos : [0, 0], size : [1, 1],
    color : new util.Color([1, 1, 1]), opacity : 1,
    flipHoriz : false, flipVert : false,
    texRes : 128, interpolate : true, depth : 0.0 
  });
  key_resp_2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Thanks"
  ThanksClock = new util.Clock();
  TheEnd = new visual.TextStim({
    win: psychoJS.window,
    name: 'TheEnd',
    text: 'All done. Thank you!\nPlease wait for the experiment to finish saving your data.',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.07,  wrapWidth: undefined, ori: 0,
    color: new util.Color('pink'),  opacity: 1,
    depth: 0.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var _Space1_allKeys;
var Initial_instructionComponents;
function Initial_instructionRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Initial_instruction'-------
    t = 0;
    Initial_instructionClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    Space1.keys = undefined;
    Space1.rt = undefined;
    _Space1_allKeys = [];
    // keep track of which components have finished
    Initial_instructionComponents = [];
    Initial_instructionComponents.push(initialinstr);
    Initial_instructionComponents.push(Space1);
    
    Initial_instructionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


var continueRoutine;
function Initial_instructionRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Initial_instruction'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = Initial_instructionClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *initialinstr* updates
    if (t >= 0.0 && initialinstr.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      initialinstr.tStart = t;  // (not accounting for frame time here)
      initialinstr.frameNStart = frameN;  // exact frame index
      
      initialinstr.setAutoDraw(true);
    }

    
    // *Space1* updates
    if (t >= 0.0 && Space1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Space1.tStart = t;  // (not accounting for frame time here)
      Space1.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { Space1.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { Space1.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { Space1.clearEvents(); });
    }

    if (Space1.status === PsychoJS.Status.STARTED) {
      let theseKeys = Space1.getKeys({keyList: ['space'], waitRelease: false});
      _Space1_allKeys = _Space1_allKeys.concat(theseKeys);
      if (_Space1_allKeys.length > 0) {
        Space1.keys = _Space1_allKeys[_Space1_allKeys.length - 1].name;  // just the last key pressed
        Space1.rt = _Space1_allKeys[_Space1_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    Initial_instructionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function Initial_instructionRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Initial_instruction'-------
    Initial_instructionComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('Space1.keys', Space1.keys);
    if (typeof Space1.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('Space1.rt', Space1.rt);
        routineTimer.reset();
        }
    
    Space1.stop();
    // the Routine "Initial_instruction" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _Space2_allKeys;
var Expt_InstructionsComponents;
function Expt_InstructionsRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Expt_Instructions'-------
    t = 0;
    Expt_InstructionsClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    Space2.keys = undefined;
    Space2.rt = undefined;
    _Space2_allKeys = [];
    // keep track of which components have finished
    Expt_InstructionsComponents = [];
    Expt_InstructionsComponents.push(exptinstr);
    Expt_InstructionsComponents.push(Space2);
    
    Expt_InstructionsComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function Expt_InstructionsRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Expt_Instructions'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = Expt_InstructionsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *exptinstr* updates
    if (t >= 0.0 && exptinstr.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      exptinstr.tStart = t;  // (not accounting for frame time here)
      exptinstr.frameNStart = frameN;  // exact frame index
      
      exptinstr.setAutoDraw(true);
    }

    
    // *Space2* updates
    if (t >= 0.0 && Space2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Space2.tStart = t;  // (not accounting for frame time here)
      Space2.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { Space2.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { Space2.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { Space2.clearEvents(); });
    }

    if (Space2.status === PsychoJS.Status.STARTED) {
      let theseKeys = Space2.getKeys({keyList: ['space'], waitRelease: false});
      _Space2_allKeys = _Space2_allKeys.concat(theseKeys);
      if (_Space2_allKeys.length > 0) {
        Space2.keys = _Space2_allKeys[_Space2_allKeys.length - 1].name;  // just the last key pressed
        Space2.rt = _Space2_allKeys[_Space2_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    Expt_InstructionsComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function Expt_InstructionsRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Expt_Instructions'-------
    Expt_InstructionsComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('Space2.keys', Space2.keys);
    if (typeof Space2.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('Space2.rt', Space2.rt);
        routineTimer.reset();
        }
    
    Space2.stop();
    // the Routine "Expt_Instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var Practice_loop;
var currentLoop;
function Practice_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  Practice_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'SimonPractice.xlsx',
    seed: undefined, name: 'Practice_loop'
  });
  psychoJS.experiment.addLoop(Practice_loop); // add the loop to the experiment
  currentLoop = Practice_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  Practice_loop.forEach(function() {
    const snapshot = Practice_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(PracticeFixRoutineBegin(snapshot));
    thisScheduler.add(PracticeFixRoutineEachFrame(snapshot));
    thisScheduler.add(PracticeFixRoutineEnd(snapshot));
    thisScheduler.add(PracticeTrialsRoutineBegin(snapshot));
    thisScheduler.add(PracticeTrialsRoutineEachFrame(snapshot));
    thisScheduler.add(PracticeTrialsRoutineEnd(snapshot));
    thisScheduler.add(FeedbackRoutineBegin(snapshot));
    thisScheduler.add(FeedbackRoutineEachFrame(snapshot));
    thisScheduler.add(FeedbackRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function Practice_loopLoopEnd() {
  psychoJS.experiment.removeLoop(Practice_loop);

  return Scheduler.Event.NEXT;
}


var trials;
function trialsLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  trials = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'SimonStimuli.xlsx',
    seed: undefined, name: 'trials'
  });
  psychoJS.experiment.addLoop(trials); // add the loop to the experiment
  currentLoop = trials;  // we're now the current loop

  // Schedule all the trials in the trialList:
  trials.forEach(function() {
    const snapshot = trials.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(ExperimentFixRoutineBegin(snapshot));
    thisScheduler.add(ExperimentFixRoutineEachFrame(snapshot));
    thisScheduler.add(ExperimentFixRoutineEnd(snapshot));
    thisScheduler.add(ExpTrialsRoutineBegin(snapshot));
    thisScheduler.add(ExpTrialsRoutineEachFrame(snapshot));
    thisScheduler.add(ExpTrialsRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function trialsLoopEnd() {
  psychoJS.experiment.removeLoop(trials);

  return Scheduler.Event.NEXT;
}


var trials_2;
function trials_2LoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  trials_2 = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'SimonStimuli.xlsx',
    seed: undefined, name: 'trials_2'
  });
  psychoJS.experiment.addLoop(trials_2); // add the loop to the experiment
  currentLoop = trials_2;  // we're now the current loop

  // Schedule all the trials in the trialList:
  trials_2.forEach(function() {
    const snapshot = trials_2.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(ExperimentFixRoutineBegin(snapshot));
    thisScheduler.add(ExperimentFixRoutineEachFrame(snapshot));
    thisScheduler.add(ExperimentFixRoutineEnd(snapshot));
    thisScheduler.add(ExpTrialsRoutineBegin(snapshot));
    thisScheduler.add(ExpTrialsRoutineEachFrame(snapshot));
    thisScheduler.add(ExpTrialsRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function trials_2LoopEnd() {
  psychoJS.experiment.removeLoop(trials_2);

  return Scheduler.Event.NEXT;
}


var PracticeFixComponents;
function PracticeFixRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'PracticeFix'-------
    t = 0;
    PracticeFixClock.reset(); // clock
    frameN = -1;
    routineTimer.add(1.250000);
    // update component parameters for each repeat
    imageFix.setImage('Fixation.jpeg');
    // keep track of which components have finished
    PracticeFixComponents = [];
    PracticeFixComponents.push(imageFix);
    
    PracticeFixComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


var frameRemains;
function PracticeFixRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'PracticeFix'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = PracticeFixClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *imageFix* updates
    if (t >= 0.75 && imageFix.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      imageFix.tStart = t;  // (not accounting for frame time here)
      imageFix.frameNStart = frameN;  // exact frame index
      
      imageFix.setAutoDraw(true);
    }

    frameRemains = 0.75 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (imageFix.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      imageFix.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    PracticeFixComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function PracticeFixRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'PracticeFix'-------
    PracticeFixComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    return Scheduler.Event.NEXT;
  };
}


var _response_allKeys;
var PracticeTrialsComponents;
function PracticeTrialsRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'PracticeTrials'-------
    t = 0;
    PracticeTrialsClock.reset(); // clock
    frameN = -1;
    routineTimer.add(4.000000);
    // update component parameters for each repeat
    imagePractice.setImage(ImageFile);
    response.keys = undefined;
    response.rt = undefined;
    _response_allKeys = [];
    // keep track of which components have finished
    PracticeTrialsComponents = [];
    PracticeTrialsComponents.push(imagePractice);
    PracticeTrialsComponents.push(response);
    
    PracticeTrialsComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function PracticeTrialsRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'PracticeTrials'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = PracticeTrialsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *imagePractice* updates
    if (t >= 0.0 && imagePractice.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      imagePractice.tStart = t;  // (not accounting for frame time here)
      imagePractice.frameNStart = frameN;  // exact frame index
      
      imagePractice.setAutoDraw(true);
    }

    frameRemains = 0.0 + 4 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (imagePractice.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      imagePractice.setAutoDraw(false);
    }
    
    // *response* updates
    if (t >= 0.0 && response.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      response.tStart = t;  // (not accounting for frame time here)
      response.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { response.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { response.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { response.clearEvents(); });
    }

    frameRemains = 0.0 + 4 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (response.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      response.status = PsychoJS.Status.FINISHED;
  }

    if (response.status === PsychoJS.Status.STARTED) {
      let theseKeys = response.getKeys({keyList: ['m', 'z'], waitRelease: false});
      _response_allKeys = _response_allKeys.concat(theseKeys);
      if (_response_allKeys.length > 0) {
        response.keys = _response_allKeys[0].name;  // just the first key pressed
        response.rt = _response_allKeys[0].rt;
        // was this correct?
        if (response.keys == CorrAns) {
            response.corr = 1;
        } else {
            response.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    PracticeTrialsComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function PracticeTrialsRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'PracticeTrials'-------
    PracticeTrialsComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // was no response the correct answer?!
    if (response.keys === undefined) {
      if (['None','none',undefined].includes(CorrAns)) {
         response.corr = 1;  // correct non-response
      } else {
         response.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for thisExp (ExperimentHandler)
    psychoJS.experiment.addData('response.keys', response.keys);
    psychoJS.experiment.addData('response.corr', response.corr);
    if (typeof response.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('response.rt', response.rt);
        routineTimer.reset();
        }
    
    response.stop();
    return Scheduler.Event.NEXT;
  };
}


var msg;
var FeedbackComponents;
function FeedbackRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Feedback'-------
    t = 0;
    FeedbackClock.reset(); // clock
    frameN = -1;
    routineTimer.add(1.000000);
    // update component parameters for each repeat
    if ((! response.keys)) {
        msg = "Failed to respond";
    } else {
        if (response.corr) {
            msg = "Correct!";
        } else {
            msg = "Oops! That was wrong";
        }
    }
    
    Feedback_2.setText(msg);
    // keep track of which components have finished
    FeedbackComponents = [];
    FeedbackComponents.push(Feedback_2);
    
    FeedbackComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function FeedbackRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Feedback'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = FeedbackClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *Feedback_2* updates
    if (t >= 0.0 && Feedback_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Feedback_2.tStart = t;  // (not accounting for frame time here)
      Feedback_2.frameNStart = frameN;  // exact frame index
      
      Feedback_2.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (Feedback_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      Feedback_2.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    FeedbackComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function FeedbackRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Feedback'-------
    FeedbackComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    return Scheduler.Event.NEXT;
  };
}


var _Space3_allKeys;
var Begin_ExperimentComponents;
function Begin_ExperimentRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Begin_Experiment'-------
    t = 0;
    Begin_ExperimentClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    Space3.keys = undefined;
    Space3.rt = undefined;
    _Space3_allKeys = [];
    // keep track of which components have finished
    Begin_ExperimentComponents = [];
    Begin_ExperimentComponents.push(text);
    Begin_ExperimentComponents.push(Space3);
    
    Begin_ExperimentComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function Begin_ExperimentRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Begin_Experiment'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = Begin_ExperimentClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text* updates
    if (t >= 0.0 && text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text.tStart = t;  // (not accounting for frame time here)
      text.frameNStart = frameN;  // exact frame index
      
      text.setAutoDraw(true);
    }

    
    // *Space3* updates
    if (t >= 0.0 && Space3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Space3.tStart = t;  // (not accounting for frame time here)
      Space3.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { Space3.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { Space3.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { Space3.clearEvents(); });
    }

    if (Space3.status === PsychoJS.Status.STARTED) {
      let theseKeys = Space3.getKeys({keyList: ['space'], waitRelease: false});
      _Space3_allKeys = _Space3_allKeys.concat(theseKeys);
      if (_Space3_allKeys.length > 0) {
        Space3.keys = _Space3_allKeys[_Space3_allKeys.length - 1].name;  // just the last key pressed
        Space3.rt = _Space3_allKeys[_Space3_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    Begin_ExperimentComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function Begin_ExperimentRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Begin_Experiment'-------
    Begin_ExperimentComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('Space3.keys', Space3.keys);
    if (typeof Space3.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('Space3.rt', Space3.rt);
        routineTimer.reset();
        }
    
    Space3.stop();
    // the Routine "Begin_Experiment" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var ExperimentFixComponents;
function ExperimentFixRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'ExperimentFix'-------
    t = 0;
    ExperimentFixClock.reset(); // clock
    frameN = -1;
    routineTimer.add(1.250000);
    // update component parameters for each repeat
    imageFixation.setImage('Fixation.jpeg');
    // keep track of which components have finished
    ExperimentFixComponents = [];
    ExperimentFixComponents.push(imageFixation);
    
    ExperimentFixComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function ExperimentFixRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'ExperimentFix'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = ExperimentFixClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *imageFixation* updates
    if (t >= 0.75 && imageFixation.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      imageFixation.tStart = t;  // (not accounting for frame time here)
      imageFixation.frameNStart = frameN;  // exact frame index
      
      imageFixation.setAutoDraw(true);
    }

    frameRemains = 0.75 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (imageFixation.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      imageFixation.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    ExperimentFixComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ExperimentFixRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'ExperimentFix'-------
    ExperimentFixComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    return Scheduler.Event.NEXT;
  };
}


var _key_resp_2_allKeys;
var ExpTrialsComponents;
function ExpTrialsRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'ExpTrials'-------
    t = 0;
    ExpTrialsClock.reset(); // clock
    frameN = -1;
    routineTimer.add(4.000000);
    // update component parameters for each repeat
    imageTrials.setImage(ImageFile);
    key_resp_2.keys = undefined;
    key_resp_2.rt = undefined;
    _key_resp_2_allKeys = [];
    // keep track of which components have finished
    ExpTrialsComponents = [];
    ExpTrialsComponents.push(imageTrials);
    ExpTrialsComponents.push(key_resp_2);
    
    ExpTrialsComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function ExpTrialsRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'ExpTrials'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = ExpTrialsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *imageTrials* updates
    if (t >= 0.0 && imageTrials.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      imageTrials.tStart = t;  // (not accounting for frame time here)
      imageTrials.frameNStart = frameN;  // exact frame index
      
      imageTrials.setAutoDraw(true);
    }

    frameRemains = 0.0 + 4 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (imageTrials.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      imageTrials.setAutoDraw(false);
    }
    
    // *key_resp_2* updates
    if (t >= 0.0 && key_resp_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_2.tStart = t;  // (not accounting for frame time here)
      key_resp_2.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_2.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_2.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_2.clearEvents(); });
    }

    frameRemains = 0.0 + 4 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (key_resp_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      key_resp_2.status = PsychoJS.Status.FINISHED;
  }

    if (key_resp_2.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_2.getKeys({keyList: ['m', 'z'], waitRelease: false});
      _key_resp_2_allKeys = _key_resp_2_allKeys.concat(theseKeys);
      if (_key_resp_2_allKeys.length > 0) {
        key_resp_2.keys = _key_resp_2_allKeys[0].name;  // just the first key pressed
        key_resp_2.rt = _key_resp_2_allKeys[0].rt;
        // was this correct?
        if (key_resp_2.keys == CorrAns) {
            key_resp_2.corr = 1;
        } else {
            key_resp_2.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    ExpTrialsComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ExpTrialsRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'ExpTrials'-------
    ExpTrialsComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // was no response the correct answer?!
    if (key_resp_2.keys === undefined) {
      if (['None','none',undefined].includes(CorrAns)) {
         key_resp_2.corr = 1;  // correct non-response
      } else {
         key_resp_2.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for thisExp (ExperimentHandler)
    psychoJS.experiment.addData('key_resp_2.keys', key_resp_2.keys);
    psychoJS.experiment.addData('key_resp_2.corr', key_resp_2.corr);
    if (typeof key_resp_2.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_2.rt', key_resp_2.rt);
        routineTimer.reset();
        }
    
    key_resp_2.stop();
    return Scheduler.Event.NEXT;
  };
}


var _Space4_allKeys;
var BreakComponents;
function BreakRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Break'-------
    t = 0;
    BreakClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    Space4.keys = undefined;
    Space4.rt = undefined;
    _Space4_allKeys = [];
    // keep track of which components have finished
    BreakComponents = [];
    BreakComponents.push(text_2);
    BreakComponents.push(Space4);
    
    BreakComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function BreakRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Break'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = BreakClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text_2* updates
    if (t >= 0.0 && text_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_2.tStart = t;  // (not accounting for frame time here)
      text_2.frameNStart = frameN;  // exact frame index
      
      text_2.setAutoDraw(true);
    }

    
    // *Space4* updates
    if (t >= 0.0 && Space4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Space4.tStart = t;  // (not accounting for frame time here)
      Space4.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { Space4.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { Space4.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { Space4.clearEvents(); });
    }

    if (Space4.status === PsychoJS.Status.STARTED) {
      let theseKeys = Space4.getKeys({keyList: ['space'], waitRelease: false});
      _Space4_allKeys = _Space4_allKeys.concat(theseKeys);
      if (_Space4_allKeys.length > 0) {
        Space4.keys = _Space4_allKeys[_Space4_allKeys.length - 1].name;  // just the last key pressed
        Space4.rt = _Space4_allKeys[_Space4_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    BreakComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function BreakRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Break'-------
    BreakComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('Space4.keys', Space4.keys);
    if (typeof Space4.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('Space4.rt', Space4.rt);
        routineTimer.reset();
        }
    
    Space4.stop();
    // the Routine "Break" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var ThanksComponents;
function ThanksRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Thanks'-------
    t = 0;
    ThanksClock.reset(); // clock
    frameN = -1;
    routineTimer.add(2.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    ThanksComponents = [];
    ThanksComponents.push(TheEnd);
    
    ThanksComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function ThanksRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Thanks'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = ThanksClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *TheEnd* updates
    if (t >= 0.0 && TheEnd.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      TheEnd.tStart = t;  // (not accounting for frame time here)
      TheEnd.frameNStart = frameN;  // exact frame index
      
      TheEnd.setAutoDraw(true);
    }

    frameRemains = 0.0 + 2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (TheEnd.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      TheEnd.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    ThanksComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ThanksRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Thanks'-------
    ThanksComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    return Scheduler.Event.NEXT;
  };
}


function endLoopIteration(thisScheduler, loop) {
  // ------Prepare for next entry------
  return function () {
    if (typeof loop !== 'undefined') {
      // ------Check if user ended loop early------
      if (loop.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(loop);
        }
      thisScheduler.stop();
      } else {
        const thisTrial = loop.getCurrentTrial();
        if (typeof thisTrial === 'undefined' || !('isTrials' in thisTrial) || thisTrial.isTrials) {
          psychoJS.experiment.nextEntry(loop);
        }
      }
    return Scheduler.Event.NEXT;
    }
  };
}


function importConditions(trials) {
  return function () {
    psychoJS.importAttributes(trials.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
